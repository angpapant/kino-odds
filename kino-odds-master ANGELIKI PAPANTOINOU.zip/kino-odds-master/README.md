# kino-odds
Kino game playing 20 odds

Listbox listbox= newlistBox();
listbox setitems(new[]{"1" "3" "5" "7" "9" "11" "13" "15" "17" "19" "21" "23" "25" "27" "29" "31" "33" "35" 37" "39"}};
Listbox.Odds();




Kino game playing 20 even

Listbox listbox= newlistBox();
listbox setitems(new[]{"2" "4" "6" "8" "10" "12" "14" "16" "18" "20" "22" "24" "26" "28" "30" "32" "34" "36" 38" "40"}};
Listbox.even();



Kino game playing 20 draws

Listbox listbox= newlistBox();
listbox setitems(new[]{"2" "6" "24" "8" "14" "65" "14" "36" "12" "20" "23" "27" "25" "29" "50" "42" "44" "37" 38" "80"}};
Listbox.draws();




kino game number of draws

Listbox listbox= newlistBox();
listbox setitems(new[]{"2" "6" "24" "3" "8" "1" "6" "4" "3" "8" "3" "7" "5" "9" "5" "2" "4" "7" 75" "80"}};
Listbox.numberofdraws(5);





list of total earnings

List<totalearnings>list=newlist<totalearnings>();
  
  
  
  
  run a draw
  
  public delegate double
  multi ( o  e);
  static void main (string[]args)
  
  { multi vnut=(o,e)=>o*e;
  
  consoleWriteline (mult (2,5));
  }
  
 //predicative voolean
 
 odd/even
 
 
 
 show draw numbers
 
 List<drawnumbers>list=newlist<drawnumbers>();
  
  
  calculate earnings
  
  
  static void main (string)[]args) 
  calc earnings=delegate (double 3, double 8)
  console.WriteLine("sum "22" 6+16);
  
 
